The content of the zip file specifies the security groups to create, the members to add to these security groups and the firewall rules to apply based on the plan security operation that generated the zip file. 
The importer tool available at https://via.vmw.com/vrni-rule-import-vmc-nsxt can be used to automatically create these rules in NSX-T.

Note: The importer tool is to be used only to create rules in NSX-T.
